package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Timetable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TimetableService {
    List<Timetable>getAllTimeTables(String keyword);
    void addTimetable(Timetable timetable);
    Timetable getTimetableById(long id);
    void deleteTimetableById(long id);
}
