package com.example.CB007297EEAassignment.Controller;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.Classroom;
import com.example.CB007297EEAassignment.Service.ClassroomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ClassroomController {

    @Autowired
    private ClassroomService classroomService;

    @GetMapping("/classroom")
    public String viewHomePage(Model model,@Param("keyword")String keyword){
        List<Classroom> listClassroom = classroomService.getAllClassrooms(keyword);
        model.addAttribute("listClassrooms",classroomService.getAllClassrooms(keyword));
        model.addAttribute("keyword",keyword);
        return "classroom";
    }

    @GetMapping("/addNewClassroom")
    public String addClassroom(Model model){
        Classroom classroom = new Classroom();
        model.addAttribute("classroom",classroom);
        return "addClassroom";
    }

    @PostMapping("/addClassroom")
    public String addClassroom(@ModelAttribute("classroom")Classroom classroom){
        classroomService.addClassroom(classroom);
        return "redirect:/classroom";
    }

    @GetMapping("/updateClassroom/{id}")
    public String showFormForUpdateClassroom(@PathVariable(value = "id")long id, Model model){
        //Get batch from the service
        Classroom classroom=classroomService.getClassroomById(id);

        model.addAttribute("classroom",classroom);
        return "updateClassroom";
    }

    @GetMapping("/deleteClassroom/{id}")
    public String deleteClassroom(@PathVariable(value = "id")long id){
        this.classroomService.deleteClassroomById(id);
        return "redirect:/classroom";

    }
}
