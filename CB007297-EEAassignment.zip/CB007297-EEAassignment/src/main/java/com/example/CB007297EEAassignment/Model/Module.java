package com.example.CB007297EEAassignment.Model;

import javax.persistence.*;

@Entity
@Table(name = "module", uniqueConstraints = {
        @UniqueConstraint(columnNames = "id")
})
public class Module {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String moduleName;


    public Module(String moduleName) {
        this.moduleName = moduleName;
    }

    public Module(){

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }
}
