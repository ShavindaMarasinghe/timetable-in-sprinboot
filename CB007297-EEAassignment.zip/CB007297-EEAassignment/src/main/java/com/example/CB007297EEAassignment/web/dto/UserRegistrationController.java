package com.example.CB007297EEAassignment.web.dto;

import com.example.CB007297EEAassignment.Service.UserService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Registration")
public class UserRegistrationController {
    @Autowired
    private UserService userService;

    @GetMapping("/loadPage")
    public String showRegistrationForm(Model model){
        model.addAttribute("user",new UserRegistrationDto());
        return "Registration";
    }

    @PostMapping("/save")
    public String registerUserAccount(@ModelAttribute("user") UserRegistrationDto registrationDto){
        userService.save(registrationDto);
        return "redirect:/Login";

    }


}
