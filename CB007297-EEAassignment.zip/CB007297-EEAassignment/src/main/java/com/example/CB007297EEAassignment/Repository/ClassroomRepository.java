package com.example.CB007297EEAassignment.Repository;

import com.example.CB007297EEAassignment.Model.Classroom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClassroomRepository extends JpaRepository<Classroom,Long> {
    @Query("SELECT c FROM Classroom c WHERE c.className LIKE %?1%")
    public List<Classroom> findAll(String keyword);
}
