package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Batch;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface BatchService {
    List<Batch> getAllBatches(String keyword);
    void addBatch(Batch batch);
    Batch getBatchById(long id);
    void deleteBatchById(long id);
}
