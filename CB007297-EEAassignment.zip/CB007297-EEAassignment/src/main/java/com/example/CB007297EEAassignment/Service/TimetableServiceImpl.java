package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Classroom;
import com.example.CB007297EEAassignment.Model.Timetable;
import com.example.CB007297EEAassignment.Repository.TimetableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TimetableServiceImpl implements TimetableService {

    @Autowired
    private TimetableRepository timetableRepository;


    @Override
    public List<Timetable> getAllTimeTables(String keyword) {
        if (keyword != null){
            return timetableRepository.findAll(keyword);
        }
        return timetableRepository.findAll();
    }

    @Override
    public void addTimetable(Timetable timetable) {

        this.timetableRepository.save(timetable);
    }

    @Override
    public Timetable getTimetableById(long id) {
        Optional<Timetable> optional=timetableRepository.findById(id);
        Timetable timetable = null;
        if (optional.isPresent()){
            timetable = optional.get();
        }else{
            throw new RuntimeException("Timetable not found for id ::" + id);
        }
        return timetable;
    }

    @Override
    public void deleteTimetableById(long id) {
        this.timetableRepository.deleteById(id);

    }
}
