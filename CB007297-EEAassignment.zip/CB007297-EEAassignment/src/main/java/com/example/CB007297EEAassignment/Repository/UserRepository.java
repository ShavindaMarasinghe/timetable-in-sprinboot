package com.example.CB007297EEAassignment.Repository;

import com.example.CB007297EEAassignment.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    @Query("SELECT u from User u where u.Email = ?1")
    User findByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.First_Name LIKE %?1%")
    public List<User> findAll(String keyword);

}
