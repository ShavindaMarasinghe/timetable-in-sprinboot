package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.Role;
import com.example.CB007297EEAassignment.Model.User;
import com.example.CB007297EEAassignment.Repository.UserRepository;
import com.example.CB007297EEAassignment.web.dto.UserRegistrationDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }

    @Override
    public User save(UserRegistrationDto registrationDto) {
      User user = new User(registrationDto.getFirstName(),registrationDto.getLastName(),registrationDto.getEmail(),
              registrationDto.getPhoneNumber(),passwordEncoder.encode(registrationDto.getPassword()),
              Arrays.asList(new Role(registrationDto.getRole())));

      return userRepository.save(user);
    }


    @Override
    public List<User> getAllUsers(String keyword) {
        if (keyword != null){
            return userRepository.findAll(keyword);
        }
        return userRepository.findAll();
    }

    @Override
    public User getUserById(int id) {
        Optional<User> optional=userRepository.findById(id);
        User user = null;
        if (optional.isPresent()){
            user = optional.get();
        }else{
            throw new RuntimeException("User not found for id ::" + id);
        }
        return user;
    }

    @Override
    public void deleteUserById(int id) {

        this.userRepository.deleteById(id);
    }

    @Override
    public boolean passwordencode(String password, String pass) {
        return passwordEncoder.matches(password, pass);
    }

    @Override
    public UserDetails loadUserByUsername(String email)throws UsernameNotFoundException{
        User user = userRepository.findByEmail(email);
        if(user == null){
            throw new UsernameNotFoundException("Invalid Username or Password");
        }

        return new  org.springframework.security.core.userdetails.User(user.getEmail(),user.getPassword(),mapRolesToAuthorities(user.getRoles()));
    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
        return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());

    }
}
