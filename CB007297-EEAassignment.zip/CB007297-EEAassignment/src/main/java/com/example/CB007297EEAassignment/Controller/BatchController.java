package com.example.CB007297EEAassignment.Controller;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.Module;
import com.example.CB007297EEAassignment.Service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class BatchController {

    @Autowired
    private BatchService batchService;

    @GetMapping("/batch")
    public String viewHomePage(Model model, @Param("keyword")String keyword){

        List<Batch> listBatches = batchService.getAllBatches(keyword);
        model.addAttribute("listBatches",batchService.getAllBatches(keyword));
        model.addAttribute("keyword",keyword);
        return "batch";
    }

    @GetMapping("/addNewBatch")
    public String addBatch(Model model){
        Batch batch = new Batch();
        model.addAttribute("batch",batch);
        return "addBatch";
    }

    @PostMapping("/addBatch")
    public String addBatch(@ModelAttribute("batch")Batch batch){
        batchService.addBatch(batch);
        return "redirect:/batch";
    }

    @GetMapping("/updateBatch/{id}")
    public String showFormForUpdateBatch(@PathVariable(value = "id")long id, Model model){
        //Get batch from the service
        Batch batch=batchService.getBatchById(id);

        model.addAttribute("batch",batch);
        return "updateBatch";
    }

    @GetMapping("/deleteBatch/{id}")
    public String deleteBatch(@PathVariable(value = "id")long id){
        this.batchService.deleteBatchById(id);
        return "redirect:/batch";

    }
}
