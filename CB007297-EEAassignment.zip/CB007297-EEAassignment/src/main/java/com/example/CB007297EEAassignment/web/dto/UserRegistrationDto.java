package com.example.CB007297EEAassignment.web.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;

@Data
@AllArgsConstructor
@NoArgsConstructor


public class UserRegistrationDto {
    private String FirstName;
    private String LastName;
    private String Email;
    private int PhoneNumber;
    private String Password;
    private String Role;


}
