package com.example.CB007297EEAassignment.Controller;

import com.example.CB007297EEAassignment.Model.Timetable;
import com.example.CB007297EEAassignment.Service.TimetableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class TimetableController {

    @Autowired
    private TimetableService timetableService;

    @GetMapping("/timetable")
    public String viewHomePage(Model model, @Param("keyword")String keyword){

        List<Timetable> listTimetable = timetableService.getAllTimeTables(keyword);
        model.addAttribute("listTimetables",timetableService.getAllTimeTables(keyword));
        model.addAttribute("keyword",keyword);
        return "timetable";
    }

    @GetMapping("/studenthome")
    public String viewStudentHomePage(Model model, @Param("keyword")String keyword){

        List<Timetable> listTimetable = timetableService.getAllTimeTables(keyword);
        model.addAttribute("listTimetables",timetableService.getAllTimeTables(keyword));
        model.addAttribute("keyword",keyword);
        return "studenthome";
    }

    @GetMapping("/studentsearch")
    public String studentSearch(){
       return "studentsearch";
    }

    @GetMapping("/addNewTimetable")
    public String addTimetable(Model model){
        Timetable timetable = new Timetable();
        model.addAttribute("timetable",timetable);
        return "addTimetable";
    }

    @PostMapping("/addTimetable")
    public String addBatch(@ModelAttribute("timetable")Timetable timetable){
        timetableService.addTimetable(timetable);
        return "redirect:/timetable";
    }

    @GetMapping("/updateTimetable/{id}")
    public String showFormForUpdateTimetable(@PathVariable(value = "id")long id, Model model){
        //Get timetable from the service
        Timetable timetable=timetableService.getTimetableById(id);

        model.addAttribute("timetable",timetable);
        return "updateTimetable";
    }

    @GetMapping("/deleteTimetable/{id}")
    public String deleteTimetable(@PathVariable(value = "id")long id){
        this.timetableService.deleteTimetableById(id);
        return "redirect:/timetable";
    }

    @GetMapping("/search")
    public String ShowSearchpage(){
        return "search";
    }

}
