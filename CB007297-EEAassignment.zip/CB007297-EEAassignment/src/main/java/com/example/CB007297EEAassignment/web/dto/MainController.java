package com.example.CB007297EEAassignment.web.dto;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/Login")
    public String login(){
        return "Login";
    }

    @GetMapping("/")
    public String home()
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if(authentication.getAuthorities().stream().anyMatch(r -> r.getAuthority().equals("Admin")))
        {
            return "redirect:/adminhomepage";
        }
        if(authentication.getAuthorities().stream().anyMatch(r -> r.getAuthority().equals("Student")))
        {
            return "redirect:/studenthomepage";
        }
        if(authentication.getAuthorities().stream().anyMatch(r -> r.getAuthority().equals("Lecturer")))
        {
            return "redirect:/lecturehomepage";
        }
        return "Index";
    }
    @GetMapping("/adminhomepage")
    private String loadAdminhomepage(){
        return "Index";
    }
    @GetMapping("/studenthomepage")
    private String loadstudenthomepage(){
        return "redirect:/studentsearch";
    }
    @GetMapping("/lecturehomepage")
    private String loadlecturehomepage(){
        return "lecturehome";
    }

}
