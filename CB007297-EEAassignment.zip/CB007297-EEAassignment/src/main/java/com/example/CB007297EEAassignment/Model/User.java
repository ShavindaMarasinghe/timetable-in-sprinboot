package com.example.CB007297EEAassignment.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Collection;


@Entity
@Table(name = "user", uniqueConstraints = {
        @UniqueConstraint(columnNames = "Email")
})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int UserID;


    private String First_Name;

    private String Last_Name;


    private String Email;

    private int PhoneNumber;

    private String Password;

    @ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinTable(
            name = "User_Roles",
            joinColumns = @JoinColumn(
                    name = "UserID",referencedColumnName = "UserID"),
            inverseJoinColumns = @JoinColumn(
                    name = "RoleID",referencedColumnName = "id"
            )
    )
    private Collection <Role> roles;

    public User(String first_Name, String last_Name, String email, int phoneNumber, String password,
                Collection<Role> roles) {
        First_Name = first_Name;
        Last_Name = last_Name;
        Email = email;
        PhoneNumber = phoneNumber;
        Password = password;
        this.roles = roles;
    }

    public User() {
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public Collection<Role> getRoles() {
        return roles;
    }

    public void setRoles(Collection<Role> roles) {
        this.roles = roles;
    }
}
