package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Module;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ModuleService {
    List<Module> getAllModules(String keyword);
    void addModule(Module module);
    Module getModuleById(long id);
    void deleteModuleById(long id);
}
