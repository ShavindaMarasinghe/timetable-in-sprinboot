package com.example.CB007297EEAassignment.Controller;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.User;
import com.example.CB007297EEAassignment.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/user")
    public String viewHomePage(Model model, @Param("keyword")String keyword){

        List<User> listUsers = userService.getAllUsers(keyword);
        model.addAttribute("listUsers",userService.getAllUsers(keyword));
        model.addAttribute("keyword",keyword);
        return "user";
    }

    @GetMapping("/updateUser/{id}")
    public String showFormForUser(@PathVariable(value = "id") int id, Model model){
        //Get user from the service
        User user=userService.getUserById(id);

        model.addAttribute("user",user);
        return "updateUser";
    }

    @GetMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable(value = "id")int id){
        this.userService.deleteUserById(id);
        return "redirect:/user";

    }


}
