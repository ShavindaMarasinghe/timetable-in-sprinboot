package com.example.CB007297EEAassignment.Model;

import javax.persistence.*;

@Entity
@Table(name = "batch",uniqueConstraints = {
        @UniqueConstraint(columnNames = "id")
})
public class Batch {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String batchName;
    private String courseName;

    public Batch(long id, String batchName, String courseName) {
        this.id = id;
        this.batchName = batchName;
        this.courseName = courseName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBatchName() {
        return batchName;
    }

    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Batch(){

    }
}
