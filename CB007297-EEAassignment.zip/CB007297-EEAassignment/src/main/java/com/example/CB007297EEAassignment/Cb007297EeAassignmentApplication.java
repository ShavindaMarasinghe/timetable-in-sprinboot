package com.example.CB007297EEAassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cb007297EeAassignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cb007297EeAassignmentApplication.class, args);
	}

}
