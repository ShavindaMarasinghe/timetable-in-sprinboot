package com.example.CB007297EEAassignment.API;

import com.example.CB007297EEAassignment.Model.*;
import com.example.CB007297EEAassignment.Repository.*;
import com.example.CB007297EEAassignment.Service.BatchService;
import com.example.CB007297EEAassignment.Service.ClassroomService;
import com.example.CB007297EEAassignment.Service.ModuleService;
import com.example.CB007297EEAassignment.Service.UserService;
import com.example.CB007297EEAassignment.web.dto.UserRegistrationDto;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/timetableAPI/v1/")
public class TimetableAPIController {

    @Autowired
    public ClassroomRepository classroomRepository;

    @Autowired
    public ClassroomService classroomService;

    @Autowired
    public ModuleService moduleService;

    @Autowired
    private TimetableRepository timetableRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    public BatchService batchService;

    @Autowired
    private UserService userService;


    //******* View ALL Timetables *******
    @GetMapping("/timetables")
    public List<Timetable> viewTimetables() {
        return timetableRepository.findAll();
    }


    //****** View All Users ******
    @GetMapping("/users")
    public List<User> viewUsers() {
        return userRepository.findAll();
    }


    //****** View All Batches *******
    @GetMapping("/batches")
    public List<Batch> viewBatches() {
        return batchRepository.findAll();
    }


    //****** View All Modules ******
    @GetMapping("/modules")
    public List<Module> viewModules() {
        return moduleRepository.findAll();
    }


    //****** Login Method *****

    @GetMapping("/login/{username}/{password}")
    public JSONObject login(@PathVariable(value = "username") String username,
                            @PathVariable(value = "password") String password) {
        JSONObject obj = new JSONObject();
        User user = new User();
        user = userRepository.findByEmail(username);
        String pass = user.getPassword();
        if (user != null) {
            if (userService.passwordencode(password, pass)) {

                obj.put("user", user);
                obj.put("Response", "Correct");
                obj.put("Role", user.getRoles());
                return obj;
            } else {
                obj.put("Response", "Wrong");
                return obj;
            }
        } else {
            obj.put("Response", "Error");
            return obj;
        }
    }


    //**** Add new Batch Method *****
    @PostMapping("admin/saveBatch")
    public JSONObject saveBatch(@RequestBody Batch batch){
        JSONObject obj = new JSONObject();

        batchService.addBatch(batch);

        obj.put("Response", "Success");
        return obj;
    }


    // ******* Add Classroom Method *****
    @PostMapping("admin/saveClassroom")
    public JSONObject saveClassroom(@RequestBody Classroom classroom){
        JSONObject obj = new JSONObject();

        classroomService.addClassroom(classroom);

        obj.put("Response", "Success");
        return obj;
    }


    // ***** Add Module Method *******
    @PostMapping("admin/saveModule")
    public JSONObject saveModule(@RequestBody Module module){
        JSONObject obj = new JSONObject();

        moduleService.addModule(module);

        obj.put("Response", "Success");
        return obj;
    }


    //****** Register User *******
    @PostMapping("/register")
    public JSONObject RegisterUser(@RequestBody UserRegistrationDto user){
        JSONObject obj = new JSONObject();

        userService.save(user);

        obj.put("Response", "Success");
        return obj;
    }

    @PostMapping("Batch/Update")
    public void updateBatch(@RequestBody Batch batch){
        batchService.getBatchById(batch.getId());
        batchService.addBatch(batch);

    }

    @DeleteMapping("Batch/Delete")
    public void deleteBatch(@RequestBody Batch batch){
        batchService.deleteBatchById(batch.getId());
        batchRepository.delete(batch);
    }

    @PostMapping("Module/Update")
    public void updateModule(@RequestBody Module module){
        moduleService.getModuleById(module.getId());
        moduleService.addModule(module);

    }

    @DeleteMapping("Module/Delete")
    public void deleteModule(@RequestBody Module module){
        moduleService.deleteModuleById(module.getId());
        moduleRepository.delete(module);
    }


}
