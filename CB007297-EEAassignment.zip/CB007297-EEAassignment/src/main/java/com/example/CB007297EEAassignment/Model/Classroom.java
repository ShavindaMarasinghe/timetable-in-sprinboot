package com.example.CB007297EEAassignment.Model;

import javax.persistence.*;

@Entity
@Table(name = "classroom", uniqueConstraints = {
        @UniqueConstraint(columnNames = "id")
})
public class Classroom {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String className;
    private String floor;

    public Classroom() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }
}
