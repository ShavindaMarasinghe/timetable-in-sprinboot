package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.User;
import com.example.CB007297EEAassignment.web.dto.UserRegistrationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    User save(UserRegistrationDto registrationDto);
    List<User> getAllUsers(String keyword);
    User getUserById(int id);
    void deleteUserById(int id);

    boolean passwordencode(String password, String pass);
}
