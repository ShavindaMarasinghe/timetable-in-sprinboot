package com.example.CB007297EEAassignment.Controller;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Model.Module;
import com.example.CB007297EEAassignment.Service.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ModuleController {

    @Autowired
    private ModuleService moduleService;

    @GetMapping("/module")
    public String viewHomePage(Model model, @Param("keyword")String keyword){
        List<Module> listModules = moduleService.getAllModules(keyword);
        model.addAttribute("listModules",moduleService.getAllModules(keyword));
        model.addAttribute("keyword",keyword);
        return "module";
    }

    @GetMapping("/addNewModule")
    public String addModule(Model model){
        Module module = new Module();
        model.addAttribute("module",module);
        return "addModule";
    }

    @PostMapping("/addModule")
    public String addModule(@ModelAttribute("module")Module module){
        moduleService.addModule(module);
        return "redirect:/module";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id")long id, Model model){
        //Get module from the service
        Module module=moduleService.getModuleById(id);

        model.addAttribute("module",module);
        return "updateModule";
    }

    @GetMapping("/deleteModule/{id}")
    public String deleteModule(@PathVariable(value = "id")long id){
        this.moduleService.deleteModuleById(id);
        return "redirect:/module";

    }
}
