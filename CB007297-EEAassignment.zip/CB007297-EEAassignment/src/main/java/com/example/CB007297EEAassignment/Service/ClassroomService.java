package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Classroom;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ClassroomService {
    List<Classroom> getAllClassrooms(String keyword);
    void addClassroom(Classroom classroom);
    Classroom getClassroomById(long id);
    void deleteClassroomById(long id);
}
