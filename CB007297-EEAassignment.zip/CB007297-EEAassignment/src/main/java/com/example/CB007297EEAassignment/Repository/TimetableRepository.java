package com.example.CB007297EEAassignment.Repository;

import com.example.CB007297EEAassignment.Model.Timetable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TimetableRepository extends JpaRepository<Timetable,Long> {

    @Query("SELECT u FROM Timetable u WHERE u.batchName LIKE %?1%")
    public List<Timetable> findAll(String keyword);
}
