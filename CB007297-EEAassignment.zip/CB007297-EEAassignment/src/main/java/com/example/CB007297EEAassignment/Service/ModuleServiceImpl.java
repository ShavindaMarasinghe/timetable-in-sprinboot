package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Module;
import com.example.CB007297EEAassignment.Repository.ModuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ModuleServiceImpl implements ModuleService{

    @Autowired
    private ModuleRepository moduleRepository;

    @Override
    public List<Module> getAllModules(String keyword){
        if (keyword != null){
            return moduleRepository.findAll(keyword);
        }
        return moduleRepository.findAll();
    }

    @Override
    public void addModule(Module module) {

        this.moduleRepository.save(module);
    }

    @Override
    public Module getModuleById(long id) {
        Optional<Module> optional=moduleRepository.findById(id);
        Module module = null;
        if (optional.isPresent()){
            module = optional.get();
        }else{
            throw new RuntimeException("Module not found for id ::" + id);
        }
        return module;

    }

    @Override
    public void deleteModuleById(long id) {

        this.moduleRepository.deleteById(id);
    }
}
