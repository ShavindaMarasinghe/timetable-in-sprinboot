package com.example.CB007297EEAassignment.Model;

import javax.persistence.*;

@Entity
@Table(name = "timetable", uniqueConstraints = {
        @UniqueConstraint(columnNames = "id")
})
public class Timetable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String batchName;
    private String moduleName;
    private String date;
    private String startTime;
    private String duration;
    private String classRoom;
    private String floor;
    private String lecturer;

    public Timetable() {

    }

    public Timetable(long id, String batchName, String moduleName, String date, String startTime,
                     String duration, String classRoom, String floor, String lecturer) {
        this.id = id;
        this.batchName = batchName;
        this.moduleName = moduleName;
        this.date = date;
        this.startTime = startTime;
        this.duration = duration;
        this.classRoom = classRoom;
        this.floor = floor;
        this.lecturer = lecturer;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBatchName() {
        return batchName;
    }

    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getClassRoom() {
        return classRoom;
    }

    public void setClassRoom(String classRoom) {
        this.classRoom = classRoom;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }
}
