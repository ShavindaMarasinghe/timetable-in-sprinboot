package com.example.CB007297EEAassignment.Service;

import com.example.CB007297EEAassignment.Model.Batch;
import com.example.CB007297EEAassignment.Repository.BatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BatchServiceImpl implements BatchService {

    @Autowired
    private BatchRepository batchRepository;

    //Displaying all batches
    @Override
    public List<Batch> getAllBatches(String keyword) {
        if (keyword != null){
            return batchRepository.findAll(keyword);
        }
        return batchRepository.findAll();
    }

    //Adding new batch
    @Override
    public void addBatch(Batch batch) {

        this.batchRepository.save(batch);
    }

    //Getting batch by Id
    @Override
    public Batch getBatchById(long id) {
        Optional<Batch> optional=batchRepository.findById(id);
        Batch batch = null;
        if (optional.isPresent()){
            batch = optional.get();
        }else{
            throw new RuntimeException("Batch not found for id ::" + id);
        }
        return batch;
    }

    //Delete Batch
    @Override
    public void deleteBatchById(long id) {

        this.batchRepository.deleteById(id);
    }
}
