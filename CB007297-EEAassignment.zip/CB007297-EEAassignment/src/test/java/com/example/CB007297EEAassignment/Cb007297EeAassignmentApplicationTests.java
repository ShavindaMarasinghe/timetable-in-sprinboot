package com.example.CB007297EEAassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cb007297EeAassignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
